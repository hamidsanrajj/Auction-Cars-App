<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <!-- <title><?php echo e(config('app.name', 'Laravel')); ?></title> -->

    <title>E-Auction</title>
    
    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=Nunito" rel="stylesheet">


    <!-- For favicon png -->
    <!-- <link rel="shortcut icon" type="image/icon" href="logo/favicon.png"/> -->
   
    <!--font-awesome.min.css-->
    <link rel="stylesheet" href="css/font-awesome.min.css">

    <!--linear icon css-->
    <link rel="stylesheet" href="css/linearicons.css">

    <!--animate.css-->
    <link rel="stylesheet" href="css/animate.css">

    <!--flaticon.css-->
    <link rel="stylesheet" href="css/flaticon.css">

    <!--slick.css-->
    <link rel="stylesheet" href="css/slick.css">
    <link rel="stylesheet" href="css/slick-theme.css">
    
    <!--bootstrap.min.css-->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    
    <!-- bootsnav -->
    <link rel="stylesheet" href="css/bootsnav.css" > 
    
    <!--style.css-->
    <link rel="stylesheet" href="css/style.css">
    
    <!--responsive.css-->
    <link rel="stylesheet" href="css/responsive.css">


    <!-- Scripts -->
    <?php echo app('Illuminate\Foundation\Vite')(['resources/sass/app.scss', 'resources/js/app.js']); ?>
</head>
<body>
    <div id="app">


        <!--header-top start -->
        <header id="header-top" class="header-top">
            <ul>
                <li>
                    <div class="header-top-left">
                        <ul>
                            <!-- <li class="header-top-contact">
                                +1 222 777 6565
                            </li> -->
                            <li class="select-opt">
                                <select name="language" id="language">
                                    <option value="default">EN</option>
                                    <!-- <option value="Bangla">BN</option>
                                    <option value="Arabic">AB</option> -->
                                </select>
                            </li>
                            <!-- <li class="select-opt">
                                <select name="currency" id="currency">
                                    <option value="usd">USD</option>
                                    <option value="euro">Euro</option>
                                    <option value="bdt">BDT</option>
                                </select>
                            </li>
                            <li class="select-opt">
                                <a href="#"><span class="lnr lnr-magnifier"></span></a>
                            </li> -->
                        </ul>
                    </div>
                </li>
                <li class="head-responsive-right pull-right">
                    <div class="header-top-right">
                        <ul>
                            

                        <?php if(auth()->guard()->guest()): ?>
                            <?php if(Route::has('login')): ?>
                                 <li class="header-top-contact">
                                    <a href="<?php echo e(route('login')); ?>">sign in</a>
                                </li>
                            <?php endif; ?>

                            <?php if(Route::has('register')): ?>
                                <li class="header-top-contact">
                                    <a href="<?php echo e(route('register')); ?>">register</a>
                                </li>
                            <?php endif; ?>
                        <?php else: ?>
                            <li class="header-top-contact">
                                <a href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        <?php echo e(__('Logout')); ?> 
                                    </a>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                        <?php echo csrf_field(); ?>
                                    </form>

                            </li>
                        <?php endif; ?>


                        
                        </ul>
                    </div>
                </li>
            </ul>
                    
        </header><!--/.header-top-->
        <!--header-top end -->

       <main class="py-4">
           <?php echo $__env->yieldContent('content'); ?>
       </main>

       <!--footer start-->
        <footer id="footer"  class="footer">
            <div class="container">
                <div class="footer-menu">
                    <div class="row">
                        <div class="col-sm-3">
                             <div class="navbar-header">
                            </div><!--/.navbar-header-->
                        </div>
                        <div class="col-sm-9">
                            <ul class="footer-menu-item">
<!--                                 <li class="scroll"><a href="#explore">explore</a></li>
                                <li class="scroll"><a href="#reviews">review</a></li>
                                <li class="scroll"><a href="#blog">blog</a></li> -->
                                <!-- <li class=" scroll"><a href="#contact">my account</a></li> -->
                            </ul><!--/.nav -->
                        </div>
                   </div>
                </div>
                <div class="hm-footer-copyright">
                    <div class="row">
                        <div class="col-sm-12 text-center">
                            <p>
                                &copy; 2025 copyrights, All Rights Reserved.
                            </p><!--/p-->
                        </div>
                        <!-- <div class="col-sm-7">
                            <div class="footer-social">
                                <a href="#"><i class="fa fa-facebook"></i></a>  
                                <a href="#"><i class="fa fa-twitter"></i></a>
                                <a href="#"><i class="fa fa-linkedin"></i></a>
                                <a href="#"><i class="fa fa-google-plus"></i></a>
                            </div>
                        </div> -->
                    </div>
                    
                </div><!--/.hm-footer-copyright-->
            </div><!--/.container-->

            <div id="scroll-Top">
                <!-- <div class="return-to-top">
                    <i class="fa fa-angle-up " id="scroll-top" data-toggle="tooltip" data-placement="top" title="" data-original-title="Back to Top" aria-hidden="true"></i>
                </div> -->
                
            </div><!--/.scroll-Top-->

    </div>
</body>

        <script src="js/jquery.js"></script>
        
        <!--modernizr.min.js-->
        <script src="https://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.3/modernizr.min.js"></script>
        
        <!--bootstrap.min.js-->
        <script src="js/bootstrap.min.js"></script>
        
        <!-- bootsnav js -->
        <script src="js/bootsnav.js"></script>

        <!--feather.min.js-->
        <script  src="js/feather.min.js"></script>

        <!-- counter js -->
        <script src="js/jquery.counterup.min.js"></script>
        <script src="js/waypoints.min.js"></script>

        <!--slick.min.js-->
        <script src="js/slick.min.js"></script>

        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.4.1/jquery.easing.min.js"></script>
             
        <!--Custom JS-->
        <script src="js/custom.js"></script>
</html>
<?php /**PATH C:\xampp\htdocs\auction\resources\views///////layouts/app.blade.php ENDPATH**/ ?>