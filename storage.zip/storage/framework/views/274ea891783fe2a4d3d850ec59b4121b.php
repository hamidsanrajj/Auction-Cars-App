

<?php $__env->startSection('content'); ?>


<link rel="stylesheet" type="text/css" href="assets/css/home.css">




<div class="container" style="margin-bottom: -50px;">
  <div class="row card-car">

<?php if(isset($rs)): ?>
<?php $__currentLoopData = $rs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


    <div class="col-md-3">
      <div class="card">
        <img class="card-img-top" src="uploads/<?php echo e($rse->img1); ?>" alt="Card image cap">
        <div class="card-body">
          <h5 class="card-title"><?php echo e($rse->name); ?></h5>
          <div><label> Lot#  </label><span> <?php echo e($rse->lot_number); ?></span></div>

<?php if(isset($rs3)): ?>
<?php $__currentLoopData = $rs3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


          <div><label> Current Bid:  </label><span class="price"> $ <?php echo e($rse->bid_amount); ?> CAD</span></div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>



          <div><label> Location:  </label><span> <?php echo e($rse->location); ?></span></div> 
          <div class="row">
            <div class="col-md-3">
              <form action="<?php echo e(url('/')); ?>/detail" method="get">
                <?php echo csrf_field(); ?>
                <input type="text" name="id" value="<?php echo e($rse->id); ?>" hidden>
                <button id="detail" name="submit" type="submit" class="btn btn-primary">Detail</button>
              </form>
            </div>
          
            <div class="col-md-3" style="margin-left: 10px;">
              <form action="<?php echo e(url('/')); ?>/bid" method="get">
                <?php echo csrf_field(); ?>
                <input type="text" name="id" value="<?php echo e($rse->id); ?>" hidden>
                <button id="detail" name="submit" type="submit" class="btn btn-success">Bid</button>
              </form>
            </div>
          </div>


                <script type="text/javascript">
                var button1 = document.getElementById('detail');
                var button2 = document.getElementById('bid');
                button1.onclick = function() {
                  location.assign('<?php echo e(url("/detail")); ?>');
                }
                button2.onclick = function() {
                  location.assign('<?php echo e(url("/bid")); ?>');
                }
                </script>        

        </div>
      </div>      
    </div>


<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>


  </div>




<!-- <div class="center">
<div class="pagination">
  <a href="#">&laquo;</a>
  <a href="#" class="active">1</a>
  <a href="#">2</a>
  <a href="#">3</a>
  <a href="#">4</a>
  <a href="#">5</a>
  <a href="#">6</a>
  <a href="#">&raquo;</a>
</div>
</div> -->


</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\auction\resources\views/home.blade.php ENDPATH**/ ?>