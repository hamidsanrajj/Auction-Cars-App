
<style>
/* The Modal (background) */
.modal {
  display: none; /* Hidden by default */
  position: fixed; /* Stay in place */
  z-index: 1; /* Sit on top */
  padding-top: 100px; /* Location of the box */
  left: 0;
  top: 0;
  width: 100%; /* Full width */
  height: 100%; /* Full height */
  overflow: auto; /* Enable scroll if needed */
  background-color: rgb(0,0,0); /* Fallback color */
  background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
  z-index: 10000;
}

/* Modal Content */
.modal-content {
  background-color: #fefefe;
  margin: auto;
  padding: 20px;
  border: 1px solid #888;
  width: 80%;
}

/* The Close Button */
.close {
  color: #aaaaaa;
  float: right;
  font-size: 28px;
  font-weight: bold;
}

.close:hover,
.close:focus {
  color: #000;
  text-decoration: none;
  cursor: pointer;
}
</style>




<!-- The Modal -->
<div id="myModal" class="modal">

  <!-- Modal content -->
  <div class="modal-content" style="background-color: red; border: 0px;">
    <span class="close">&times;</span>
    <h1 style="color: white;">Error 403! Create Account</h1>
  </div>

</div>




        <!--welcome-hero start -->
        <section id="home" class="welcome-hero">
            <div class="container">
                <div class="welcome-hero-txt">
                    <h2>best place to find Restaurants, Food <br> that all you need </h2>
                    <!-- <p>
                        Find Best Place, Restaurant, Hotel, Real State and many more think in just One click 
                    </p> -->

                    <p>
                        Find Best Place Restaurant, Food
                    </p>
                </div>
                <div class="welcome-hero-serch-box">
                    <div class="welcome-hero-form">
                        <div class="single-welcome-hero-form">
                            <h3>what?</h3>
                            <form action="<?php echo e(url('/')); ?>/search" method="get">
                                <!-- <input disabled name="place" type="text" placeholder="Ex: palce, resturant, food, automobile" required/> -->

                                <input id="resturant" name="place" type="text" placeholder="Find palce, resturant, food" required/>
                            
                            <div class="welcome-hero-form-icon">
                                <i class="flaticon-list-with-dots"></i>
                            </div>
                        </div>
                        <div class="single-welcome-hero-form">
                            <h3>location</h3>
                         
                                <!-- <input disabled name="city" type="text" placeholder="Ex: Islamabad, Rawalpindi, Lahore" required/> -->

                                <input onclick="modal()" id="city" name="city" type="text" placeholder="Ex: Islamabad" required/>
                            
                            <div class="welcome-hero-form-icon">
                                <i class="flaticon-gps-fixed-indicator"></i>
                            </div>
                        </div>
                    </div>
                    <div class="welcome-hero-serch">
                        </form>   
                                <button id="myBtn" class="welcome-hero-btn">
                                     search  <i data-feather="search"></i> 
                                </button>
                         
                    </div>
                </div>
            </div>




        </section><!--/.welcome-hero-->
        <!--welcome-hero end -->



<script>
// Get the modal
var modal = document.getElementById("myModal");

// Get the button that opens the modal
var btn = document.getElementById("myBtn");

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

// When the user clicks the button, open the modal 
btn.onclick = function() {
  modal.style.display = "block";
}

// When the user clicks on <span> (x), close the modal
span.onclick = function() {
  modal.style.display = "none";
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
  if (event.target == modal) {
    modal.style.display = "none";
  }
}
</script>



        <!--list-topics start -->
        <section id="list-topics" class="list-topics">
            <div class="container">
                <div class="list-topics-content">
                    <ul>
                        <li style="display: none;">
                            <div class="single-list-topics-content">
                                <div class="single-list-topics-icon">
                                    <i class="flaticon-restaurant"></i>
                                </div>
                                <h2><a href="#">resturants</a></h2>
                                <!-- <p>150 listings</p> -->
                            </div>
                        </li>
                        <li style="display: none;">
                            <div class="single-list-topics-content">
                                <div class="single-list-topics-icon">
                                    <i class="flaticon-travel"></i>
                                </div>
                                <h2><a href="#">destination</a></h2>
                                <!-- <p>214 listings</p> -->
                            </div>
                        </li>
                        <li style="display: none;">
                            <div class="single-list-topics-content">
                                <div class="single-list-topics-icon">
                                    <i class="flaticon-building"></i>
                                </div>
                                <h2><a href="#">hotels</a></h2>
                                <!-- <p>185 listings</p> -->
                            </div>
                        </li>
                        <li style="display: none;">
                            <div class="single-list-topics-content">
                                <div class="single-list-topics-icon">
                                    <i class="flaticon-pills"></i>
                                </div>
                                <h2><a href="#">healthcare</a></h2>
                                <!-- <p>200 listings</p> -->
                            </div>
                        </li>
                        <li style="display: none;">
                            <div class="single-list-topics-content">
                                <div class="single-list-topics-icon">
                                    <i class="flaticon-transport"></i>
                                </div>
                                <h2><a href="#">workshop</a></h2>
                                <!-- <p>120 listings</p> -->
                            </div>
                        </li>
                    </ul>
                </div>
            </div><!--/.container-->
        </section><!--/.list-topics-->
        <!--list-topics end-->

        <!--works start -->
        <section id="works" class="works" style="margin-top: 50px;">
            <div class="container">
                <div class="section-header">
                    <h2>how it works</h2>
                    <p>Learn More about how our website works</p>
                </div><!--/.section-header-->
                <div class="works-content">
                    <div class="row">
                        <div class="col-md-4 col-sm-6">
                            <div class="single-how-works">
                                <div class="single-how-works-icon">
                                    <i class="flaticon-lightbulb-idea"></i>
                                </div>
                                <h2><a href="#">choose <span> what to</span> do</a></h2>
                                <p>
                                    Select your spot, search your spot and click up to find and make reservation. we have locations you will enjoy while exploring these spots and many more
                                </p>
                                <!-- <button class="welcome-hero-btn how-work-btn" onclick="window.location.href='#'">
                                    read more
                                </button> -->
                            </div>
                        </div>
                        <div class="col-md-4 col-sm-6">
                            <div class="single-how-works">
                                <div class="single-how-works-icon">
                                    <i class="flaticon-networking"></i>
                                </div>
                                <h2><a href="#">find <span> what you want</span></a></h2>
                                <p>
                                    You can find out your spot instantly. we have listings of lot of desired locations you will enjoy while exploring these spots and many more
                                </p>
                                <!-- <button class="welcome-hero-btn how-work-btn" onclick="window.location.href='#'">
                                    read more
                                </button> -->
                            </div>
                        </div>
                        <div class="col-md-4 col-sm-6">
                            <div class="single-how-works">
                                <div class="single-how-works-icon">
                                    <i class="flaticon-location-on-road"></i>
                                </div>
                                <h2><a href="#">explore <span> amazing</span> place</a></h2>
                                <p>
                                    we have listings of lot of desired amazing locations you will enjoy with family while exploring these spots and many more.
                                </p>
                                <!-- <button class="welcome-hero-btn how-work-btn" onclick="window.location.href='#'">
                                    read more
                                </button> -->
                            </div>
                        </div>
                    </div>
                </div>
            </div><!--/.container-->
        
        </section><!--/.works-->
        <!--works end -->

        <!--explore start -->
        <section id="explore" class="explore" style="display: none;">
            <div class="container">
                <div class="section-header">
                    <h2>explore</h2>
                    <p>Explore New place, food, culture around the world and many more</p>
                </div><!--/.section-header-->
                <div class="explore-content">
                    <div class="row">
                        <div class=" col-md-4 col-sm-6">
                            <div class="single-explore-item">
                                <div class="single-explore-img">
                                    <img src="images/explore/e1.jpg" alt="explore image">
                                    <div class="single-explore-img-info">
                                        <button onclick="window.location.href='#'">best rated</button>
                                        <div class="single-explore-image-icon-box">
                                            <ul>
                                                <li>
                                                    <div class="single-explore-image-icon">
                                                        <i class="fa fa-arrows-alt"></i>
                                                    </div>
                                                </li>
                                                <li>
                                                    <div class="single-explore-image-icon">
                                                        <i class="fa fa-bookmark-o"></i>
                                                    </div>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <div class="single-explore-txt bg-theme-1">
                                    <h2><a href="#">tommy helfinger bar</a></h2>
                                    <p class="explore-rating-price">
                                        <span class="explore-rating">5.0</span>
                                        <a href="#"> 10 ratings</a> 
                                        <span class="explore-price-box">
                                            form
                                            <span class="explore-price">5$-300$</span>
                                        </span>
                                         <a href="#">resturent</a>
                                    </p>
                                    <div class="explore-person">
                                        <div class="row">
                                            <div class="col-sm-2">
                                                <div class="explore-person-img">
                                                    <a href="#">
                                                        <img src="images/explore/person.png" alt="explore person">
                                                    </a>
                                                </div>
                                            </div>
                                            <div class="col-sm-10">
                                                <p>
                                                    Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incid ut labore et dolore magna aliqua.... 
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="explore-open-close-part">
                                        <div class="row">
                                            <div class="col-sm-5">
                                                <button class="close-btn" onclick="window.location.href='#'">close now</button>
                                            </div>
                                            <div class="col-sm-7">
                                                <div class="explore-map-icon">
                                                    <a href="#"><i data-feather="map-pin"></i></a>
                                                    <a href="#"><i data-feather="upload"></i></a>
                                                    <a href="#"><i data-feather="heart"></i></a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 col-sm-6">
                            <div class="single-explore-item">
                                <div class="single-explore-img">
                                    <img src="images/explore/e2.jpg" alt="explore image">
                                    <div class="single-explore-img-info">
                                        <button onclick="window.location.href='#'">featured</button>
                                        <div class="single-explore-image-icon-box">
                                            <ul>
                                                <li>
                                                    <div class="single-explore-image-icon">
                                                        <i class="fa fa-arrows-alt"></i>
                                                    </div>
                                                </li>
                                                <li>
                                                    <div class="single-explore-image-icon">
                                                        <i class="fa fa-bookmark-o"></i>
                                                    </div>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <div class="single-explore-txt bg-theme-2">
                                    <h2><a href="#">swim and dine resort</a></h2>
                                    <p class="explore-rating-price">
                                        <span class="explore-rating">4.5</span>
                                        <a href="#"> 8 ratings</a> 
                                        <span class="explore-price-box">
                                            form
                                            <span class="explore-price">50$-500$</span>
                                        </span>
                                         <a href="#">hotel</a>
                                    </p>
                                    <div class="explore-person">
                                        <div class="row">
                                            <div class="col-sm-2">
                                                <div class="explore-person-img">
                                                    <a href="#">
                                                        <img src="images/explore/person.png" alt="explore person">
                                                    </a>
                                                </div>
                                            </div>
                                            <div class="col-sm-10">
                                                <p>
                                                    Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incid ut labore et dolore magna aliqua.... 
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="explore-open-close-part">
                                        <div class="row">
                                            <div class="col-sm-5">
                                                <button class="close-btn open-btn" onclick="window.location.href='#'">open now</button>
                                            </div>
                                            <div class="col-sm-7">
                                                <div class="explore-map-icon">
                                                    <a href="#"><i data-feather="map-pin"></i></a>
                                                    <a href="#"><i data-feather="upload"></i></a>
                                                    <a href="#"><i data-feather="heart"></i></a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 col-sm-6">
                            <div class="single-explore-item">
                                <div class="single-explore-img">
                                    <img src="images/explore/e3.jpg" alt="explore image">
                                    <div class="single-explore-img-info">
                                        <button onclick="window.location.href='#'">best rated</button>
                                        <div class="single-explore-image-icon-box">
                                            <ul>
                                                <li>
                                                    <div class="single-explore-image-icon">
                                                        <i class="fa fa-arrows-alt"></i>
                                                    </div>
                                                </li>
                                                <li>
                                                    <div class="single-explore-image-icon">
                                                        <i class="fa fa-bookmark-o"></i>
                                                    </div>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <div class="single-explore-txt bg-theme-3">
                                    <h2><a href="#">europe tour</a></h2>
                                    <p class="explore-rating-price">
                                        <span class="explore-rating">5.0</span>
                                        <a href="#"> 15 ratings</a> 
                                        <span class="explore-price-box">
                                            form
                                            <span class="explore-price">5k$-10k$</span>
                                        </span>
                                         <a href="#">destination</a>
                                    </p>
                                    <div class="explore-person">
                                        <div class="row">
                                            <div class="col-sm-2">
                                                <div class="explore-person-img">
                                                    <a href="#">
                                                        <img src="images/explore/person.png" alt="explore person">
                                                    </a>
                                                </div>
                                            </div>
                                            <div class="col-sm-10">
                                                <p>
                                                    Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incid ut labore et dolore magna aliqua.... 
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="explore-open-close-part">
                                        <div class="row">
                                            <div class="col-sm-5">
                                                <button class="close-btn" onclick="window.location.href='#'">close now</button>
                                            </div>
                                            <div class="col-sm-7">
                                                <div class="explore-map-icon">
                                                    <a href="#"><i data-feather="map-pin"></i></a>
                                                    <a href="#"><i data-feather="upload"></i></a>
                                                    <a href="#"><i data-feather="heart"></i></a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class=" col-md-4 col-sm-6">
                            <div class="single-explore-item">
                                <div class="single-explore-img">
                                    <img src="images/explore/e4.jpg" alt="explore image">
                                    <div class="single-explore-img-info">
                                        <button onclick="window.location.href='#'">most view</button>
                                        <div class="single-explore-image-icon-box">
                                            <ul>
                                                <li>
                                                    <div class="single-explore-image-icon">
                                                        <i class="fa fa-arrows-alt"></i>
                                                    </div>
                                                </li>
                                                <li>
                                                    <div class="single-explore-image-icon">
                                                        <i class="fa fa-bookmark-o"></i>
                                                    </div>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <div class="single-explore-txt bg-theme-4">
                                    <h2><a href="#">banglow with swiming pool</a></h2>
                                    <p class="explore-rating-price">
                                        <span class="explore-rating">5.0</span>
                                        <a href="#"> 10 ratings</a> 
                                        <span class="explore-price-box">
                                            form
                                            <span class="explore-price">10k$-15k$</span>
                                        </span>
                                         <a href="#">real estate</a>
                                    </p>
                                    <div class="explore-person">
                                        <div class="row">
                                            <div class="col-sm-2">
                                                <div class="explore-person-img">
                                                    <a href="#">
                                                        <img src="images/explore/person.png" alt="explore person">
                                                    </a>
                                                </div>
                                            </div>
                                            <div class="col-sm-10">
                                                <p>
                                                    Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incid ut labore et dolore magna aliqua.... 
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="explore-open-close-part">
                                        <div class="row">
                                            <div class="col-sm-5">
                                                <button class="close-btn" onclick="window.location.href='#'">close now</button>
                                            </div>
                                            <div class="col-sm-7">
                                                <div class="explore-map-icon">
                                                    <a href="#"><i data-feather="map-pin"></i></a>
                                                    <a href="#"><i data-feather="upload"></i></a>
                                                    <a href="#"><i data-feather="heart"></i></a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 col-sm-6">
                            <div class="single-explore-item">
                                <div class="single-explore-img">
                                    <img src="images/explore/e5.jpg" alt="explore image">
                                    <div class="single-explore-img-info">
                                        <button onclick="window.location.href='#'">featured</button>
                                        <div class="single-explore-image-icon-box">
                                            <ul>
                                                <li>
                                                    <div class="single-explore-image-icon">
                                                        <i class="fa fa-arrows-alt"></i>
                                                    </div>
                                                </li>
                                                <li>
                                                    <div class="single-explore-image-icon">
                                                        <i class="fa fa-bookmark-o"></i>
                                                    </div>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <div class="single-explore-txt bg-theme-2">
                                    <h2><a href="#">vintage car expo</a></h2>
                                    <p class="explore-rating-price">
                                        <span class="explore-rating">4.2</span>
                                        <a href="#"> 8 ratings</a> 
                                        <span class="explore-price-box">
                                            form
                                            <span class="explore-price">500$-1200$</span>
                                        </span>
                                         <a href="#">automotion</a>
                                    </p>
                                    <div class="explore-person">
                                        <div class="row">
                                            <div class="col-sm-2">
                                                <div class="explore-person-img">
                                                    <a href="#">
                                                        <img src="images/explore/person.png" alt="explore person">
                                                    </a>
                                                </div>
                                            </div>
                                            <div class="col-sm-10">
                                                <p>
                                                    Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incid ut labore et dolore magna aliqua.... 
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="explore-open-close-part">
                                        <div class="row">
                                            <div class="col-sm-5">
                                                <button class="close-btn open-btn" onclick="window.location.href='#'">open now</button>
                                            </div>
                                            <div class="col-sm-7">
                                                <div class="explore-map-icon">
                                                    <a href="#"><i data-feather="map-pin"></i></a>
                                                    <a href="#"><i data-feather="upload"></i></a>
                                                    <a href="#"><i data-feather="heart"></i></a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 col-sm-6">
                            <div class="single-explore-item">
                                <div class="single-explore-img">
                                    <img src="images/explore/e6.jpg" alt="explore image">
                                    <div class="single-explore-img-info">
                                        <button onclick="window.location.href='#'">best rated</button>
                                        <div class="single-explore-image-icon-box">
                                            <ul>
                                                <li>
                                                    <div class="single-explore-image-icon">
                                                        <i class="fa fa-arrows-alt"></i>
                                                    </div>
                                                </li>
                                                <li>
                                                    <div class="single-explore-image-icon">
                                                        <i class="fa fa-bookmark-o"></i>
                                                    </div>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <div class="single-explore-txt bg-theme-5">
                                    <h2><a href="#">thailand tour</a></h2>
                                    <p class="explore-rating-price">
                                        <span class="explore-rating">5.0</span>
                                        <a href="#"> 15 ratings</a> 
                                        <span class="explore-price-box">
                                            form
                                            <span class="explore-price">5k$-10k$</span>
                                        </span>
                                         <a href="#">destination</a>
                                    </p>
                                    <div class="explore-person">
                                        <div class="row">
                                            <div class="col-sm-2">
                                                <div class="explore-person-img">
                                                    <a href="#">
                                                        <img src="images/explore/person.png" alt="explore person">
                                                    </a>
                                                </div>
                                            </div>
                                            <div class="col-sm-10">
                                                <p>
                                                    Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incid ut labore et dolore magna aliqua.... 
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="explore-open-close-part">
                                        <div class="row">
                                            <div class="col-sm-5">
                                                <button class="close-btn" onclick="window.location.href='#'">close now</button>
                                            </div>
                                            <div class="col-sm-7">
                                                <div class="explore-map-icon">
                                                    <a href="#"><i data-feather="map-pin"></i></a>
                                                    <a href="#"><i data-feather="upload"></i></a>
                                                    <a href="#"><i data-feather="heart"></i></a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div><!--/.container-->

        </section><!--/.explore-->
        <!--explore end -->

        <!--reviews start -->
        <section id="reviews" class="reviews" style="display: none;">
            <div class="section-header">
                <h2>clients reviews</h2>
                <p>What our client say about us</p>
            </div><!--/.section-header-->
            <div class="reviews-content">
                <div class="testimonial-carousel">
                    <div class="single-testimonial-box">
                        <div class="testimonial-description">
                            <div class="testimonial-info">
                                <div class="testimonial-img">
                                    <img src="images/clients/c1.png" alt="clients">
                                </div><!--/.testimonial-img-->
                                <div class="testimonial-person">
                                    <h2>Tom Leakar</h2>
                                    <h4>london, UK</h4>
                                    <div class="testimonial-person-star">
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                    </div>
                                </div><!--/.testimonial-person-->
                            </div><!--/.testimonial-info-->
                            <div class="testimonial-comment">
                                <p>
                                    Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Sed ut perspiciatis eaque.
                                </p>
                            </div><!--/.testimonial-comment-->
                        </div><!--/.testimonial-description-->
                    </div><!--/.single-testimonial-box-->
                    <div class="single-testimonial-box">
                        <div class="testimonial-description">
                            <div class="testimonial-info">
                                <div class="testimonial-img">
                                    <img src="images/clients/c2.png" alt="clients">
                                </div><!--/.testimonial-img-->
                                <div class="testimonial-person">
                                    <h2>monirul islam</h2>
                                    <h4>london, UK</h4>
                                    <div class="testimonial-person-star">
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                    </div>
                                </div><!--/.testimonial-person-->
                            </div><!--/.testimonial-info-->
                            <div class="testimonial-comment">
                                <p>
                                    Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Sed ut perspiciatis eaque.
                                </p>
                            </div><!--/.testimonial-comment-->
                        </div><!--/.testimonial-description-->
                    </div><!--/.single-testimonial-box-->
                    <div class="single-testimonial-box">
                        <div class="testimonial-description">
                            <div class="testimonial-info">
                                <div class="testimonial-img">
                                    <img src="images/clients/c3.png" alt="clients">
                                </div><!--/.testimonial-img-->
                                <div class="testimonial-person">
                                    <h2>Shohrab Hossain</h2>
                                    <h4>london, UK</h4>
                                    <div class="testimonial-person-star">
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                    </div>
                                </div><!--/.testimonial-person-->
                            </div><!--/.testimonial-info-->
                            <div class="testimonial-comment">
                                <p>
                                    Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Sed ut perspiciatis eaque.
                                </p>
                            </div><!--/.testimonial-comment-->
                        </div><!--/.testimonial-description-->
                    </div><!--/.single-testimonial-box-->
                    <div class="single-testimonial-box">
                        <div class="testimonial-description">
                            <div class="testimonial-info">
                                <div class="testimonial-img">
                                    <img src="images/clients/c4.png" alt="clients">
                                </div><!--/.testimonial-img-->
                                <div class="testimonial-person">
                                    <h2>Tom Leakar</h2>
                                    <h4>london, UK</h4>
                                    <div class="testimonial-person-star">
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                    </div>
                                </div><!--/.testimonial-person-->
                            </div><!--/.testimonial-info-->
                            <div class="testimonial-comment">
                                <p>
                                    Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Sed ut perspiciatis eaque.
                                </p>
                            </div><!--/.testimonial-comment-->
                        </div><!--/.testimonial-description-->
                    </div><!--/.single-testimonial-box-->
                    <div class="single-testimonial-box">
                        <div class="testimonial-description">
                            <div class="testimonial-info">
                                <div class="testimonial-img">
                                    <img src="images/clients/c1.png" alt="clients">
                                </div><!--/.testimonial-img-->
                                <div class="testimonial-person">
                                    <h2>Tom Leakar</h2>
                                    <h4>london, UK</h4>
                                    <div class="testimonial-person-star">
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                    </div>
                                </div><!--/.testimonial-person-->
                            </div><!--/.testimonial-info-->
                            <div class="testimonial-comment">
                                <p>
                                    Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Sed ut perspiciatis eaque.
                                </p>
                            </div><!--/.testimonial-comment-->
                        </div><!--/.testimonial-description-->
                    </div><!--/.single-testimonial-box-->
                    <div class="single-testimonial-box">
                        <div class="testimonial-description">
                            <div class="testimonial-info">
                                <div class="testimonial-img">
                                    <img src="images/clients/c2.png" alt="clients">
                                </div><!--/.testimonial-img-->
                                <div class="testimonial-person">
                                    <h2>monirul islam</h2>
                                    <h4>london, UK</h4>
                                    <div class="testimonial-person-star">
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                    </div>
                                </div><!--/.testimonial-person-->
                            </div><!--/.testimonial-info-->
                            <div class="testimonial-comment">
                                <p>
                                    Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Sed ut perspiciatis eaque.
                                </p>
                            </div><!--/.testimonial-comment-->
                        </div><!--/.testimonial-description-->
                    </div><!--/.single-testimonial-box-->
                    <div class="single-testimonial-box">
                        <div class="testimonial-description">
                            <div class="testimonial-info">
                                <div class="testimonial-img">
                                    <img src="images/clients/c3.png" alt="clients">
                                </div><!--/.testimonial-img-->
                                <div class="testimonial-person">
                                    <h2>Shohrab Hossain</h2>
                                    <h4>london, UK</h4>
                                    <div class="testimonial-person-star">
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                    </div>
                                </div><!--/.testimonial-person-->
                            </div><!--/.testimonial-info-->
                            <div class="testimonial-comment">
                                <p>
                                    Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Sed ut perspiciatis eaque.
                                </p>
                            </div><!--/.testimonial-comment-->
                        </div><!--/.testimonial-description-->
                    </div><!--/.single-testimonial-box-->
                    <div class="single-testimonial-box">
                        <div class="testimonial-description">
                            <div class="testimonial-info">
                                <div class="testimonial-img">
                                    <img src="images/clients/c4.png" alt="clients">
                                </div><!--/.testimonial-img-->
                                <div class="testimonial-person">
                                    <h2>Tom Leakar</h2>
                                    <h4>london, UK</h4>
                                    <div class="testimonial-person-star">
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                    </div>
                                </div><!--/.testimonial-person-->
                            </div><!--/.testimonial-info-->
                            <div class="testimonial-comment">
                                <p>
                                    Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Sed ut perspiciatis eaque.
                                </p>
                            </div><!--/.testimonial-comment-->
                        </div><!--/.testimonial-description-->
                    </div><!--/.single-testimonial-box-->
                </div>
            </div>

        </section><!--/.reviews-->
        <!--reviews end -->

        <!-- statistics strat -->
        <section id="statistics"  class="statistics" style="display: none;">
            <div class="container">
                <div class="statistics-counter"> 
                    <div class="col-md-3 col-sm-6">
                        <div class="single-ststistics-box">
                            <div class="statistics-content">
                                <div class="counter">90 </div> <span>K+</span>
                            </div><!--/.statistics-content-->
                            <h3>listings</h3>
                        </div><!--/.single-ststistics-box-->
                    </div><!--/.col-->
                    <div class="col-md-3 col-sm-6">
                        <div class="single-ststistics-box">
                            <div class="statistics-content">
                                <div class="counter">40</div> <span>k+</span>
                            </div><!--/.statistics-content-->
                            <h3>listing categories</h3>
                        </div><!--/.single-ststistics-box-->
                    </div><!--/.col-->
                    <div class="col-md-3 col-sm-6">
                        <div class="single-ststistics-box">
                            <div class="statistics-content">
                                <div class="counter">65</div> <span>k+</span>
                            </div><!--/.statistics-content-->
                            <h3>visitors</h3>
                        </div><!--/.single-ststistics-box-->
                    </div><!--/.col-->
                    <div class="col-md-3 col-sm-6">
                        <div class="single-ststistics-box">
                            <div class="statistics-content">
                                <div class="counter">50</div> <span>k+</span>
                            </div><!--/.statistics-content-->
                            <h3>happy clients</h3>
                        </div><!--/.single-ststistics-box-->
                    </div><!--/.col-->
                </div><!--/.statistics-counter-->   
            </div><!--/.container-->

        </section><!--/.counter-->  
        <!-- statistics end -->

        <!--blog start -->
        <section id="blog" class="blog" style="display: none;">
            <div class="container">
                <div class="section-header">
                    <h2>news and articles</h2>
                    <p>Always upto date with our latest News and Articles </p>
                </div><!--/.section-header-->
                <div class="blog-content">
                    <div class="row">
                        <div class="col-md-4 col-sm-6">
                            <div class="single-blog-item">
                                <div class="single-blog-item-img">
                                    <img src="images/blog/b1.jpg" alt="blog image">
                                </div>
                                <div class="single-blog-item-txt">
                                    <h2><a href="#">How to find your Desired Place more quickly</a></h2>
                                    <h4>posted <span>by</span> <a href="#">admin</a> march 2018</h4>
                                    <p>
                                        Lorem ipsum dolor sit amet, consectetur de adipisicing elit, sed do eiusmod tempore incididunt ut labore et dolore magna.
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 col-sm-6">
                            <div class="single-blog-item">
                                <div class="single-blog-item-img">
                                    <img src="images/blog/b2.jpg" alt="blog image">
                                </div>
                                <div class="single-blog-item-txt">
                                    <h2><a href="#">How to find your Desired Place more quickly</a></h2>
                                    <h4>posted <span>by</span> <a href="#">admin</a> march 2018</h4>
                                    <p>
                                        Lorem ipsum dolor sit amet, consectetur de adipisicing elit, sed do eiusmod tempore incididunt ut labore et dolore magna.
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 col-sm-6">
                            <div class="single-blog-item">
                                <div class="single-blog-item-img">
                                    <img src="images/blog/b3.jpg" alt="blog image">
                                </div>
                                <div class="single-blog-item-txt">
                                    <h2><a href="#">How to find your Desired Place more quickly</a></h2>
                                    <h4>posted <span>by</span> <a href="#">admin</a> march 2018</h4>
                                    <p>
                                        Lorem ipsum dolor sit amet, consectetur de adipisicing elit, sed do eiusmod tempore incididunt ut labore et dolore magna.
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div><!--/.container-->
            
        </section><!--/.blog-->
        <!--blog end -->


<?php /**PATH C:\xampp\htdocs\listrace\resources\views/include/main.blade.php ENDPATH**/ ?>