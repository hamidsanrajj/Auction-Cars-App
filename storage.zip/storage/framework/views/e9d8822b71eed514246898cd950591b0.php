<?php echo $__env->make('include/head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('include/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<section id="sign-in" style="margin-top: 50px; margin-bottom: 50px;">
	<div class="container">
		<div class="row">
			<h2 style="margin-bottom: 30px;">Register</h2>
			<div class="form">
				<form class="form">
					<div class="row">
						<div class="col-md-5">
							<div class="form-group">
								<label>First Name</label>
								<input type="text" name="" placeholder="Enter Name" class="form-control">
							</div>
						</div>
						<div class="col-md-5">
							<div class="form-group">
								<label>Last Name</label>
								<input type="text" name="" placeholder="Enter Name" class="form-control">
							</div>
						</div>
						<div class="col-md-5">
							<div class="form-group">
								<label>Username</label>, i.e nickname
								<input type="text" name="" placeholder="Enter UserName" class="form-control">
							</div>
						</div>
						<div class="col-md-5">
							<div class="form-group">
								<label>Password</label>
								<input type="password" name="" placeholder="Enter Password" class="form-control">
							</div>
						</div>
						
					</div>
						<div class="form-group" style="margin-top: 10px;">
								<input type="submit" name="" placeholder="Enter Name" class="btn btn-success" value="Register">
						</div>
				</form>
			</div>
		</div>
	</div>
</section>

<?php echo $__env->make('include/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\listrace\resources\views//register.blade.php ENDPATH**/ ?>