<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <!-- <title><?php echo e(config('app.name', 'Laravel')); ?></title> -->

    <title>Twigle Pk</title>
    
    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=Nunito" rel="stylesheet">


    <!-- For favicon png -->
    <!-- <link rel="shortcut icon" type="image/icon" href="logo/favicon.png"/> -->
   
    <!--font-awesome.min.css-->
    <link rel="stylesheet" href="css/font-awesome.min.css">

    <!--linear icon css-->
    <link rel="stylesheet" href="css/linearicons.css">

    <!--animate.css-->
    <link rel="stylesheet" href="css/animate.css">

    <!--flaticon.css-->
    <link rel="stylesheet" href="css/flaticon.css">

    <!--slick.css-->
    <link rel="stylesheet" href="css/slick.css">
    <link rel="stylesheet" href="css/slick-theme.css">
    
    <!--bootstrap.min.css-->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    
    <!-- bootsnav -->
    <link rel="stylesheet" href="css/bootsnav.css" > 
    
    <!--style.css-->
    <link rel="stylesheet" href="css/style.css">
    
    <!--responsive.css-->
    <link rel="stylesheet" href="css/responsive.css">


    <!-- Scripts -->
    <?php echo app('Illuminate\Foundation\Vite')(['resources/sass/app.scss', 'resources/js/app.js']); ?>
</head>
<body>
    <div id="app">


        <!--header-top start -->
        <header id="header-top" class="header-top">
            <ul>
                <li>
                    <div class="header-top-left">
                        <ul>
                            <!-- <li class="header-top-contact">
                                +1 222 777 6565
                            </li> -->
                            <li class="select-opt">
                                <select name="language" id="language">
                                    <option value="default">EN</option>
                                    <!-- <option value="Bangla">BN</option>
                                    <option value="Arabic">AB</option> -->
                                </select>
                            </li>
                            <!-- <li class="select-opt">
                                <select name="currency" id="currency">
                                    <option value="usd">USD</option>
                                    <option value="euro">Euro</option>
                                    <option value="bdt">BDT</option>
                                </select>
                            </li>
                            <li class="select-opt">
                                <a href="#"><span class="lnr lnr-magnifier"></span></a>
                            </li> -->
                        </ul>
                    </div>
                </li>
                <li class="head-responsive-right pull-right">
                    <div class="header-top-right">
                        <ul>
                            

                        <?php if(auth()->guard()->guest()): ?>
                            <?php if(Route::has('login')): ?>
                                 <li class="header-top-contact">
                                    <a href="<?php echo e(route('login')); ?>">sign in</a>
                                </li>
                            <?php endif; ?>

                            <?php if(Route::has('register')): ?>
                                <li class="header-top-contact">
                                    <a href="<?php echo e(route('register')); ?>">register</a>
                                </li>
                            <?php endif; ?>
                        <?php else: ?>
                            <li class="header-top-contact">
                                <a href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        <?php echo e(__('Logout')); ?> 
                                    </a>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                        <?php echo csrf_field(); ?>
                                    </form>

                            </li>
                        <?php endif; ?>


                            <!-- <li class="header-top-contact">
                                <a href="<?php echo e(route('login')); ?>">sign in</a>
                            </li>

                            <li class="header-top-contact">
                                <a href="<?php echo e(route('register')); ?>">register</a>
                            </li> -->
                        </ul>
                    </div>
                </li>
            </ul>
                    
        </header><!--/.header-top-->
        <!--header-top end -->

 
        <!-- top-area Start -->
        <section class="top-area">
            <div class="header-area">
                <!-- Start Navigation -->
                <nav class="navbar navbar-default bootsnav  navbar-sticky navbar-scrollspy"  data-minus-value-desktop="70" data-minus-value-mobile="55" data-speed="1000">

                    <div class="container">

                        <!-- Start Header Navigation -->
                        <div class="navbar-header">
                            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-menu">
                                <i class="fa fa-bars"></i>
                            </button>
                            <a class="navbar-brand" href="<?php echo e(route('home')); ?>">Twigle Pk</a>
                        </div><!--/.navbar-header-->
                        <!-- End Header Navigation -->

                        <!-- Collect the nav links, forms, and other content for toggling -->
                        <div class="collapse navbar-collapse menu-ui-design" id="navbar-menu" style="margin-bottom: 20px;">
                           
                            <ul class="nav navbar-nav navbar-right" data-in="fadeInDown" data-out="fadeOutUp">
                                 <li><a href="<?php echo e(route('home')); ?>">home</a></li>
                                <li class="scroll"><a href="#works">how it works</a></li>
    <!--                             <li class="scroll"><a href="#explore">explore</a></li>
                                <li class="scroll"><a href="#reviews">review</a></li>
                                <li class="scroll"><a href="#blog">blog</a></li> -->
                                <li class="scroll"><a href="#contact">Subscribe</a></li>
                                <!-- <li class="scroll"><a href="#contact">Subscribe</a></li> -->
                            </ul><!--/.nav -->
                        </div><!-- /.navbar-collapse -->
                    </div><!--/.container-->
                </nav><!--/nav-->
                <!-- End Navigation -->
            </div><!--/.header-area-->
            <div class="clearfix"></div>

        </section><!-- /.top-area-->
        <!-- top-area End -->








        <nav class="navbar navbar-expand-md navbar-light bg-white shadow-sm" style="display: none;">
            <div class="container">
                <!-- <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                    <?php echo e(config('app.name', 'Laravel')); ?>

                </a> -->
<!--                 <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
                    <span class="navbar-toggler-icon"></span>
                </button> -->

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->
                    <ul class="navbar-nav me-auto">

                    </ul>

                    <!-- Right Side Of Navbar -->
                    <ul class="navbar-nav ms-auto">
                        <!-- Authentication Links -->
                        <?php if(auth()->guard()->guest()): ?>
                            <?php if(Route::has('login')): ?>
                                <!-- <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                                </li> -->
                            <?php endif; ?>

                            <?php if(Route::has('register')): ?>
                                <!-- <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                                </li> -->
                            <?php endif; ?>
                        <?php else: ?>
<!--                              <li class="nav-item dropdown">
                                <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                    <?php echo e(Auth::user()->name); ?>

                                </a>

                                <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        <?php echo e(__('Logout')); ?>

                                    </a>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </div>
                            </li>  -->
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>

       <main class="py-4">
           <?php echo $__env->yieldContent('content'); ?>
       </main>
        

        <!--subscription strat -->
        <section id="contact"  class="subscription">
            <div class="container">
                <div class="subscribe-title text-center">
                    <h2>
                        do you want to add your business listing with us?
                    </h2>
                    <p>
                        Listrace offer you to list your business with us and we very much able to promote your Business.
                    </p>
                </div>
                <div class="row">
                    <div class="col-sm-12">
                        <div class="subscription-input-group">
                            <form action="#">
                                <input type="email" class="subscription-input-form" placeholder="Enter your email here">
                                <button class="appsLand-btn subscribe-btn" onclick="window.location.href='#'">
                                    Subscribe
                                </button>
                            </form>
                        </div>
                    </div>  
                </div>
            </div>

        </section><!--/subscription-->  
        <!--subscription end -->


       <!--footer start-->
        <footer id="footer"  class="footer">
            <div class="container">
                <div class="footer-menu">
                    <div class="row">
                        <div class="col-sm-3">
                             <div class="navbar-header">
                                <a class="navbar-brand" href="index.html">Twigle Pk</a>
                            </div><!--/.navbar-header-->
                        </div>
                        <div class="col-sm-9">
                            <ul class="footer-menu-item">
                                <li class="scroll"><a href="#works">how it works</a></li>
<!--                                 <li class="scroll"><a href="#explore">explore</a></li>
                                <li class="scroll"><a href="#reviews">review</a></li>
                                <li class="scroll"><a href="#blog">blog</a></li> -->
                                <li class="scroll"><a href="#contact">Subscribe</a></li>
                                <!-- <li class=" scroll"><a href="#contact">my account</a></li> -->
                            </ul><!--/.nav -->
                        </div>
                   </div>
                </div>
                <div class="hm-footer-copyright">
                    <div class="row">
                        <div class="col-sm-5">
                            <p>
                                &copy; 2025 copyrights, All Rights Reserved.
                            </p><!--/p-->
                        </div>
                        <div class="col-sm-7">
                            <div class="footer-social">
                                <span><i class="fa fa-phone"> +92 336 0591298</i></span>
                                <!-- <a href="#"><i class="fa fa-facebook"></i></a>  
                                <a href="#"><i class="fa fa-twitter"></i></a>
                                <a href="#"><i class="fa fa-linkedin"></i></a>
                                <a href="#"><i class="fa fa-google-plus"></i></a> -->
                            </div>
                        </div>
                    </div>
                    
                </div><!--/.hm-footer-copyright-->
            </div><!--/.container-->

            <div id="scroll-Top">
                <div class="return-to-top">
                    <i class="fa fa-angle-up " id="scroll-top" data-toggle="tooltip" data-placement="top" title="" data-original-title="Back to Top" aria-hidden="true"></i>
                </div>
                
            </div><!--/.scroll-Top-->

    </div>
</body>

        <script src="js/jquery.js"></script>
        
        <!--modernizr.min.js-->
        <script src="https://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.3/modernizr.min.js"></script>
        
        <!--bootstrap.min.js-->
        <script src="js/bootstrap.min.js"></script>
        
        <!-- bootsnav js -->
        <script src="js/bootsnav.js"></script>

        <!--feather.min.js-->
        <script  src="js/feather.min.js"></script>

        <!-- counter js -->
        <script src="js/jquery.counterup.min.js"></script>
        <script src="js/waypoints.min.js"></script>

        <!--slick.min.js-->
        <script src="js/slick.min.js"></script>

        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.4.1/jquery.easing.min.js"></script>
             
        <!--Custom JS-->
        <script src="js/custom.js"></script>
</html>
<?php /**PATH C:\xampp\htdocs\listrace\resources\views/layouts/app.blade.php ENDPATH**/ ?>