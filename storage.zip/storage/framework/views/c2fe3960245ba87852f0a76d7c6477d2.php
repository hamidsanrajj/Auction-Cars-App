   
      <!--begin::App Main-->
      <main class="app-main">
        <!--begin::App Content Header-->
        <div class="app-content-header">
          <!--begin::Container-->
          <div class="container-fluid">
            <!--begin::Row-->
            <div class="row">
              <div class="col-sm-6"><h3 class="mb-0">User</h3></div>
              <div class="col-sm-6">
                <ol class="breadcrumb float-sm-end">
                  <li class="breadcrumb-item"><a href="#">User</a></li>
                  <li class="breadcrumb-item active" aria-current="page">Dashboard</li>
                </ol>
              </div>
            </div>
            <!--end::Row-->
          </div>
          <!--end::Container-->
        </div>
        <!--end::App Content Header-->
        <!--begin::App Content-->
        <div class="app-content">
          <!--begin::Container-->
          <div class="container-fluid">
            <!--begin::Row-->
              
              <div class="row">

                <form>
                  <div class="row">
                    <h4 class="mt-4 mb-4 fw-bold text-primary">Add User</h4>
                    <div class="col-md-4">
                      <label>Name</label>
                        <input
                        type="text"
                        class="form-control"
                        placeholder=""
                        aria-label="Recipient's username"
                        aria-describedby="basic-addon2"
                      />
                    </div> 
                    <div class="col-md-4">
                      <label>Username</label>
                        <input
                        type="text"
                        class="form-control"
                        placeholder=""
                        aria-label="Recipient's username"
                        aria-describedby="basic-addon2"
                      />
                    </div> 
                    <div class="col-md-4">
                      <label>Password</label>
                        <input
                        type="text"
                        class="form-control"
                        placeholder=""
                        aria-label="Recipient's username"
                        aria-describedby="basic-addon2"
                      />
                    </div>  

                  </div>  
                  

                  <input type="submit" name="submit" class="btn btn-primary me-2 mt-4 mb-4">
                </form>

              </div>

            <!-- /.row (main row) -->
          </div>
          <!--end::Container-->
        </div>
        <!--end::App Content-->
      </main>
      <!--end::App Main-->
      <!--begin::Footer--><?php /**PATH C:\xampp\htdocs\auction\resources\views//////////admin/admin/dist/pages/include/user.blade.php ENDPATH**/ ?>