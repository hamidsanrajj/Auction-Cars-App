

<?php $__env->startSection('content'); ?>



<style>
.checked {
  color: orange;
}
</style>

<section id="search-results" style="margin-top: 100px; margin-bottom: 200px;">
	<div class="container">
		<div class="row">
			<div class="col-md-10">

				<div class="search-results-box" style="border: 0.1px solid lightgray; padding: 20px; margin-bottom: 50px;  border-radius: 30px;">


 																
<?php if(isset($rs)): ?>
<?php if(count($rs)>0): ?>
<?php $__currentLoopData = $rs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    
					<div class="row">

							<div class="col-md-4">
								<img src="images/image-resturant.jpeg" style="width: 250px; height: 250px;">
							</div>
							<div class="col-md-8">
								<div class="col-md-6">
									<div> Name: </div>
									<h3><?php echo e($rse->name); ?></h3>
			 						<div> Location: </div>
			 						<h3><?php echo e($rse->location); ?></h3>
									<div> City: </div> 
									<h3><?php echo e($rse->city); ?></h3>
									<div style="height: 40px;"></div>
									<div> Rating: </div>
									<h3><?php echo e($rse->rating); ?></h3>
									<!-- <span class="fa fa-star checked"></span>
									<span class="fa fa-star checked"></span>
									<span class="fa fa-star checked"></span>
									<span class="fa fa-star"></span>
									<span class="fa fa-star"></span> -->
									<div style="height: 10px;"></div>
									<div style="color: green; font-weight: bold;"> <?php echo e($rse->status); ?> </div>
								</div>
								<div class="col-md-6">

<style type="text/css">
	.btn-danger{
		padding: 7px;
	}
	.btn-danger:hover{
		padding: 7px;
		font-size: 14px;
	}

	.btn-danger:focus{
		padding: 7px;
		font-size: 14px;
	}


	.btn-danger:active{
		padding: 7px;
		font-size: 14px;
	}


	.btn-success{
		padding: 7px;
	}
	.btn-success:hover{
		padding: 7px;
		font-size: 14px;
	}

	.btn-success:focus{
		padding: 7px;
		font-size: 14px;
	}


	.btn-success:active{
		padding: 7px;
		font-size: 14px;
	}

	.btn-primary{
		padding: 7px;
	}
	.btn-primary:hover{
		padding: 7px;
		font-size: 14px;
	}

	.btn-primary:focus{
		padding: 7px;
		font-size: 14px;
	}


	.btn-primary:active{
		padding: 7px;
		font-size: 14px;
	}

</style>

									<a href="<?php echo e($rse->menu); ?>" class="btn btn-danger" target="blank">Check Menue</a>
									<div style="height: 10px;"></div>
									<a href="<?php echo e($rse->reservation); ?>" class="btn btn-success" target="blank">Make Reservation</a>
									<div style="height: 10px;"></div>
									<a href="<?php echo e($rse->takeaway); ?>" class="btn btn-primary" target="blank">Order Takeway</a>
									<div style="height: 50px;"></div>
									<div>
										Description: 
										<div style="color: black; font-weight: bold;"> The best resturant in town having all delicious food you need </div>
									</div>
								</div>
							</div>

					</div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
<?php else: ?>
0 results                               
<?php endif; ?>
<?php endif; ?>

				</div>



			</div>
			<div class="col-md-1" style="margin-left: 70px;">



			</div>
		</div>
	</div>
</section>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\listrace\resources\views/search.blade.php ENDPATH**/ ?>