<?php echo $__env->make('include/head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('include/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<style>
.checked {
  color: orange;
}
</style>

<section id="search-results" style="margin-top: 100px; margin-bottom: 200px;">
	<div class="container">
		<div class="row">
			<div class="col-md-8">

				<div class="search-results-box" style="border: 0.1px solid lightgray; padding: 20px; margin-bottom: 50px;">


 																

	
					<div class="row">

							<div class="col-md-4">
								<img src="images/image-resturant.jpeg" style="width: 250px; height: 250px;">
							</div>
							<div class="col-md-8">
								<div class="col-md-6">
									<div> Name: </div>
									<h3><?php if(isset($rs)): ?>
                                <?php if(count($rs)>0): ?>

                                <?php $__currentLoopData = $rs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    
                                   	
                                    	<?php echo e($rse->name); ?>



                                      
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                   
                                <?php endif; ?>
                                <?php endif; ?></h3>
			 						<div> Location: </div>
			 						<h3>Name</h3>
									<div> City: </div> 
									<h3>Name</h3>
									<div style="height: 40px;"></div>
									<div> Rating: </div>
									<span class="fa fa-star checked"></span>
									<span class="fa fa-star checked"></span>
									<span class="fa fa-star checked"></span>
									<span class="fa fa-star"></span>
									<span class="fa fa-star"></span>
									<div style="height: 10px;"></div>
									<div style="color: green; font-weight: bold;"> Open Now </div>
								</div>
								<div class="col-md-6">
									<button class="btn btn-danger">Check Menue</button>
									<div style="height: 10px;"></div>
									<button class="btn btn-success">Make Reservation</button>
									<div style="height: 10px;"></div>
									<button class="btn btn-primary">Order Takeway</button>
									<div style="height: 30px;"></div>
									<div>
										Description: 
										<div style="color: black; font-weight: bold;"> The best resturant in town having all delicious items you need </div>
									</div>
								</div>
							</div>

					</div>


				</div>



			</div>
			<div class="col-md-3" style="margin-left: 70px;">



			</div>
		</div>
	</div>
</section>


<?php /**PATH C:\xampp\htdocs\listrace\resources\views//search.blade.php ENDPATH**/ ?>