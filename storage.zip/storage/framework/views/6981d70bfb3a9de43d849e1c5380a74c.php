      <footer class="app-footer">
        <!--begin::To the end-->
        <!--end::To the end-->
        <!--begin::Copyright-->
        <strong>
          Copyright &copy; 2025&nbsp;
          
        </strong>
        All rights reserved.
        <!--end::Copyright-->
      </footer>
      <!--end::Footer--><?php /**PATH C:\xampp\htdocs\auction\resources\views//////////admin/admin/dist/pages/include/footer.blade.php ENDPATH**/ ?>