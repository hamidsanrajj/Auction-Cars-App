<style type="text/css">
  /*Header*/
.headerTop{
  padding: 30px;
  background: linear-gradient(90deg,rgba(24, 12, 89, 1) 0%, rgba(9, 9, 121, 1) 32%, rgba(0, 212, 255, 1) 100%);
}

.headerTop h1{
    font-size: 35px;
  color: white;
}

sub{
    color: white;
}

.headerTop .logo-nav{
  text-decoration: none;
}

.headerTop .navbar{
  padding-top: 10px;
}

.headerTop .btn-search{
  background-color: orange; color: white;
}
</style>


<header>
<top>
    <div class="headerTop">
        <div class="row">
            <div class="col-md-2">
              <a class="logo-nav" href="<?php echo e(route('home')); ?>">
                <h1>E-Auction</h1>
                <sub>Repairable and Used Cars</sub>
              </a>
            </div>
            <div class="col-md-6">
                <nav class="navbar bg-body-tertiary">
                  <div class="container-fluid"> 
                    <form class="d-flex" role="search">
                      <div class="col-md-10">
                        <input class="form-control" type="search" placeholder="Search" aria-label="Search"/>
                      </div>
                      <div class="col-md-2">
                        <button id="searchBtn" class="btn btn-search" type="submit" style=>Search</button>
                      </div>
                    </form>
                  </div>
                </nav>  
            </div>
        </div>
    </div>
</top>  
</header><?php /**PATH C:\xampp\htdocs\auction\resources\views///////include/header.blade.php ENDPATH**/ ?>