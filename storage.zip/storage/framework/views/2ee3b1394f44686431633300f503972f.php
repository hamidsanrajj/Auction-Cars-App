

<?php $__env->startSection('content'); ?>

<h1 style="margin-top: 100px; font-size: 40px; font-weight: bolder; color: green;" class="text-center"> <i class="fa fa-check-circle" aria-hidden="true"></i>  Bid Complete</h1>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\auction\resources\views/bid-complete.blade.php ENDPATH**/ ?>