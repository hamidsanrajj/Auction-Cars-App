

<?php $__env->startSection('content'); ?>

<?php echo $__env->make('include/head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


        <!--welcome-hero start -->
        <section id="home" class="welcome-hero">
            <div class="container">
                <div class="welcome-hero-txt">
                    <h2>best place to find Restaurants, Food <br> that all you need </h2>
                    <!-- <p>
                        Find Best Place, Restaurant, Hotel, Real State and many more think in just One click 
                    </p> -->

                    <p>
                        Find Best Place Restaurant, Food
                    </p>
                </div>
                <div class="welcome-hero-serch-box">
                    <div class="welcome-hero-form">
                        <div class="single-welcome-hero-form">
                            <h3>what?</h3>
                            <form action="<?php echo e(url('/')); ?>/search" method="post">
                                <?php echo csrf_field(); ?>
                                <input type="text" name="name" value="<?php echo e(Auth::user()->name); ?>" hidden>
                                <input type="email" name="email" value="<?php echo e(Auth::user()->email); ?>" hidden>

                                <!-- <input name="place" type="text" placeholder="Ex: palce, resturant, food, automobile" required/> -->

                                <input name="place" type="text" placeholder="find resturant, food" required/>
                            
                            <div class="welcome-hero-form-icon">
                                <i class="flaticon-list-with-dots"></i>
                            </div>
                        </div>
                        <div class="single-welcome-hero-form">
                            <h3>location</h3>
                         
                                <!-- <input name="city" type="text" placeholder="Ex: Islamabad, Rawalpindi, Lahore" required/> -->

                                <input name="city" type="text" placeholder="Ex: Islamabad" required/>

                                
                            
                            <div class="welcome-hero-form-icon">
                                <i class="flaticon-gps-fixed-indicator"></i>
                            </div>
                        </div>
                    </div>
                    <div class="welcome-hero-serch">
                        
                                <button type="submit" name="submit" id="myBtn" class="welcome-hero-btn">
                                     search  <i data-feather="search"></i> 
                                </button>
                        </form>    
                    </div>
                </div>
            </div>



        </section><!--/.welcome-hero-->
        <!--welcome-hero end -->

        <!--list-topics start -->
        <section id="list-topics" class="list-topics">
            <div class="container">
                <div class="list-topics-content">
                    <ul>
                        <li style="display: none;">
                            <div class="single-list-topics-content">
                                <div class="single-list-topics-icon">
                                    <i class="flaticon-restaurant"></i>
                                </div>
                                <h2><a href="#">resturant</a></h2>
                                <!-- <p>150 listings</p> -->
                            </div>
                        </li>
                        <li style="display: none;">
                            <div class="single-list-topics-content">
                                <div class="single-list-topics-icon">
                                    <i class="flaticon-travel"></i>
                                </div>
                                <h2><a href="#">destination</a></h2>
                                <!-- <p>214 listings</p> -->
                            </div>
                        </li>
                        <li style="display: none;">
                            <div class="single-list-topics-content">
                                <div class="single-list-topics-icon">
                                    <i class="flaticon-building"></i>
                                </div>
                                <h2><a href="#">hotels</a></h2>
                                <!-- <p>185 listings</p> -->
                            </div>
                        </li>
                        <li style="display: none;">
                            <div class="single-list-topics-content">
                                <div class="single-list-topics-icon">
                                    <i class="flaticon-pills"></i>
                                </div>
                                <h2><a href="#">healthcare</a></h2>
                                <!-- <p>200 listings</p> -->
                            </div>
                        </li>
                        <li style="display: none;">
                            <div class="single-list-topics-content">
                                <div class="single-list-topics-icon">
                                    <i class="flaticon-transport"></i>
                                </div>
                                <h2><a href="#">workshop</a></h2>
                                <!-- <p>120 listings</p> -->
                            </div>
                        </li>
                    </ul>
                </div>
            </div><!--/.container-->
        </section><!--/.list-topics-->
        <!--list-topics end-->

        <!--works start -->
        <section id="works" class="works" style="margin-top: 50px;">
            <div class="container">
                <div class="section-header">
                    <h2>how it works</h2>
                    <p>Learn More about how our website works</p>
                </div><!--/.section-header-->
                <div class="works-content">
                    <div class="row">
                        <div class="col-md-4 col-sm-6">
                            <div class="single-how-works">
                                <div class="single-how-works-icon">
                                    <i class="flaticon-lightbulb-idea"></i>
                                </div>
                                <h2><a href="#">choose <span> what to</span> do</a></h2>
                                <p>
                                    Select your spot, search your spot and click up to find and make reservation. we have locations you will enjoy while exploring these spots and many more
                                </p>
                                <!-- <button class="welcome-hero-btn how-work-btn" onclick="window.location.href='#'">
                                    read more
                                </button> -->
                            </div>
                        </div>
                        <div class="col-md-4 col-sm-6">
                            <div class="single-how-works">
                                <div class="single-how-works-icon">
                                    <i class="flaticon-networking"></i>
                                </div>
                                <h2><a href="#">find <span> what you want</span></a></h2>
                                <p>
                                    You can find out your spot instantly. we have listings of lot of desired locations you will enjoy while exploring these spots and many more
                                </p>
                                <!-- <button class="welcome-hero-btn how-work-btn" onclick="window.location.href='#'">
                                    read more
                                </button> -->
                            </div>
                        </div>
                        <div class="col-md-4 col-sm-6">
                            <div class="single-how-works">
                                <div class="single-how-works-icon">
                                    <i class="flaticon-location-on-road"></i>
                                </div>
                                <h2><a href="#">explore <span> amazing</span> place</a></h2>
                                <p>
                                    we have listings of lot of desired amazing locations you will enjoy with family while exploring these spots and many more.
                                </p>
                                <!-- <button class="welcome-hero-btn how-work-btn" onclick="window.location.href='#'">
                                    read more
                                </button> -->
                            </div>
                        </div>
                    </div>
                </div>
            </div><!--/.container-->
        
        </section><!--/.works-->
        <!--works end -->


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\listrace\resources\views/home.blade.php ENDPATH**/ ?>