@include('include/head')
@include('include/banner')
@include('include/main')
@include('include/footer')