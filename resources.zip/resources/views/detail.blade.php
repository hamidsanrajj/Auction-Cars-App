@extends('layouts.app')

@section('content')



<link rel="stylesheet" type="text/css" href="assets/css/detail.css">

@if(isset($rs1))
@foreach ($rs1 as $rse)

<car-detail>
    <div class="detail">
        <div class="row">
            <div class="col-md-6">

<section>
    <div class="">
        <div class="carousel">
            <input type="radio" name="slides" checked="checked" id="slide-1">
            <input type="radio" name="slides" id="slide-2">
            <input type="radio" name="slides" id="slide-3">
            <input type="radio" name="slides" id="slide-4">
            <input type="radio" name="slides" id="slide-5">
            <input type="radio" name="slides" id="slide-6">
            <ul class="carousel__slides">
                <li class="carousel__slide">
                    <figure>
                        <div>
                            <img src="uploads/{{ $rse->img1 }}" alt="">
                        </div>
                        <figcaption>
                            {{ $rse->name }}
                            <span class="credit">{{ $rse->lot_number }}</span>
                        </figcaption>
                    </figure>
                </li>
                <li class="carousel__slide">
                    <figure>
                        <div>
                            <img src="uploads/{{ $rse->img2 }}" alt="">
                        </div>
                        <figcaption>
                            {{ $rse->name }}
                            <span class="credit">{{ $rse->lot_number }}</span>                            
                        </figcaption>
                    </figure>
                </li>
                <li class="carousel__slide">
                    <figure>
                        <div>
                            <img src="uploads/{{ $rse->img3 }}" alt="">
                        </div>
                        <figcaption>
                            {{ $rse->name }}
                            <span class="credit">{{ $rse->lot_number }}</span>                            
                        </figcaption>
                    </figure>
                </li>
                <li class="carousel__slide">
                    <figure>
                        <div>
                            <img src="uploads/{{ $rse->img4 }}" alt="">
                        </div>
                        <figcaption>
                            {{ $rse->name }}
                            <span class="credit">{{ $rse->lot_number }}</span>                            
                        </figcaption>
                    </figure>
                </li>
                <li class="carousel__slide">
                    <figure>
                        <div>
                            <img src="uploads/{{ $rse->img5 }}" alt="">
                        </div>
                        <figcaption>
                            {{ $rse->name }}
                            <span class="credit">{{ $rse->lot_number }}</span>                            
                        </figcaption>
                    </figure>
                </li>
                <li class="carousel__slide">
                    <figure>
                        <div>
                            <img src="uploads/{{ $rse->img6 }}" alt="">
                        </div>
                        <figcaption>
                            {{ $rse->name }}
                            <span class="credit">{{ $rse->lot_number }}</span>                            
                        </figcaption>
                    </figure>
                </li>
            </ul>    
            <ul class="carousel__thumbnails">
                <li>
                    <label for="slide-1"><img src="uploads/{{ $rse->img1 }}" alt=""></label>
                </li>
                <li>
                    <label for="slide-2"><img src="uploads/{{ $rse->img2 }}" alt=""></label>
                </li>
                <li>
                    <label for="slide-3"><img src="uploads/{{ $rse->img3 }}" alt=""></label>
                </li>
                <li>
                    <label for="slide-4"><img src="uploads/{{ $rse->img4 }}" alt=""></label>
                </li>
                <li>
                    <label for="slide-5"><img src="uploads/{{ $rse->img5 }}" alt=""></label>
                </li>
                <li>
                    <label for="slide-6"><img src="uploads/{{ $rse->img6 }}" alt=""></label>
                </li>
            </ul>
        </div>
    </div>
</section>


@endforeach
@endif


<!--            <shipping>
                <div class="shippingEstimate row" style="border: 1px solid lightgray; margin: 20px; border-radius: 5px;">
                    <h3>Shipping Estimate</h3>

                </div>
            </shipping> -->

                <form>
                    
                </form>



                <div class="row" style="padding: 20px;">
@if(isset($id))

                        <!-- {{Session::get('username')}} -->
                        <div class="col-md-6">
                            <form action="{{ url('/') }}/bid" method="get">
                            @csrf
                            <input type="text" name="id" value="{{ $id }}" hidden>
                            <button id="bid" type="submit" name="submit" class="form-control btn btn-warning">Place Bid</button>
                            </form>
                        </div>
                        <div class="col-md-6">
                            <button id="other" class="form-control btn btn-success">Other</button>
                        </div>
@endif

<script type="text/javascript">
var button = document.getElementById('bid');
button.onclick = function() {
  location.assign('{{ url("/bid") }}');
}
var button2 = document.getElementById('other');
button2.onclick = function() {
  location.assign('{{ url("/home") }}');
}
</script>    


                </div>


            </div>


<style type="text/css">
    .labelItem{
        border-bottom: 1px solid #f7f7f7; padding: 10px;
    }
    .vehicleDetails{
        border: 1px solid lightgray; border-radius: 10px;
    }
    .vehicleDetailsHeading{
        padding: 20px; border-bottom: 1px solid #f7f7f7; font-weight: bold;
    }

    .vehicleDetailsVal{
        font-weight: bold;
    }
</style>

@if(isset($rs1))
@foreach ($rs1 as $rse)

            <!-- <div class="col-md-4"></div> -->
            <div class="col-md-6 vehicleDetails"><div class="vehicleDetailsHeading"> <h4>Vehicle Details </h4> </div>
                <div class="row labelItem" style="">
                    <div class="col-md-6">
                        <div>Lot number:</div>
                    </div>
                    <div class="col-md-6 vehicleDetailsVal">
                        <div>{{ $rse->lot_number }}</div>
                    </div>
                </div>
                <div class="row labelItem">
                    <div class="col-md-6">
                        <div>VIN:</div>
                    </div>
                    <div class="col-md-6 vehicleDetailsVal">
                        <div>{{ $rse->vin }}</div>
                    </div>
                </div>
                <div class="row labelItem">
                    <div class="col-md-6">
                        <div>Odometer:</div>
                    </div>
                    <div class="col-md-6 vehicleDetailsVal">
                        <div>{{ $rse->odometer }}</div>
                    </div>
                </div>
                <div class="row labelItem">
                    <div class="col-md-6">
                        <div>Primary damage:</div>
                    </div>
                    <div class="col-md-6 vehicleDetailsVal">
                        <div>{{ $rse->primary_damage }}</div>
                    </div>
                </div>
                <div class="row labelItem">
                    <div class="col-md-6 ">
                        <div>Estimated retail value:</div>
                    </div>
                    <div class="col-md-6 vehicleDetailsVal">
                        <div>{{ $rse->lot_number }}</div>
                    </div>
                </div>
                <div class="row labelItem">
                    <div class="col-md-6">
                        <div>Cylinders:</div>
                    </div>
                    <div class="col-md-6 vehicleDetailsVal">
                        <div>{{ $rse->lot_number }}</div>
                    </div>
                </div>
                <div class="row labelItem">
                    <div class="col-md-6">
                        <div>Body style:</div>
                    </div>
                    <div class="col-md-6 vehicleDetailsVal">
                        <div>{{ $rse->lot_number }}</div>
                    </div>
                </div>
                <div class="row labelItem">
                    <div class="col-md-6">
                        <div>Color:</div>
                    </div>
                    <div class="col-md-6 vehicleDetailsVal">
                        <div>{{ $rse->lot_number }}</div>
                    </div>
                </div>
                <div class="row labelItem">
                    <div class="col-md-6">
                        <div>Engine type:</div>
                    </div>
                    <div class="col-md-6 vehicleDetailsVal">
                        <div>{{ $rse->lot_number }}</div>
                    </div>
                </div>
                <div class="row labelItem">
                    <div class="col-md-6">
                        <div>Transmission:</div>
                    </div>
                    <div class="col-md-6 vehicleDetailsVal">
                        <div>{{ $rse->lot_number }}</div>
                    </div>
                </div>
                <div class="row labelItem">
                    <div class="col-md-6">
                        <div>Drive:</div>
                    </div>
                    <div class="col-md-6 vehicleDetailsVal">
                        <div>{{ $rse->lot_number }}</div>
                    </div>
                </div>
                <div class="row labelItem">
                    <div class="col-md-6">
                        <div>Vehicle type:</div>
                    </div>
                    <div class="col-md-6 vehicleDetailsVal">
                        <div>{{ $rse->lot_number }}</div>
                    </div>
                </div>
                <div class="row labelItem">
                    <div class="col-md-6">
                        <div>Fuel:</div>
                    </div>
                    <div class="col-md-6 vehicleDetailsVal">
                        <div>{{ $rse->lot_number }}</div>
                    </div>
                </div>
                <div class="row labelItem">
                    <div class="col-md-6">
                        <div>Keys:</div>
                    </div>
                    <div class="col-md-6 vehicleDetailsVal">
                        <div>{{ $rse->lot_number }}</div>
                    </div>
                </div>
                <div class="row labelItem">
                    <div class="col-md-6">
                        <div>Highlights:</div>
                    </div>
                    <div class="col-md-6 vehicleDetailsVal">
                        <div>{{ $rse->lot_number }}</div>
                    </div>
                </div>
            </div>

@endforeach
@endif

        </div>
    </div>
</car-detail>



@endsection