<!DOCTYPE html>
<html>
<head>
  <meta charset='utf-8'>
  <meta http-equiv='X-UA-Compatible' content='IE=edge'>
  <title>Admin E-Auction</title>
  <meta name='viewport' content='width=device-width, initial-scale=1'>
</head>
<body>
  <script>window.location.href = './dist/pages/index.php'</script>
</body>
</html>