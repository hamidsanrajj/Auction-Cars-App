@extends('layouts.app')

@section('content')

<h1 style="margin-top: 100px; font-size: 40px; font-weight: bolder; color: green;" class="text-center"> <i class="fa fa-check-circle" aria-hidden="true"></i>  Bid Complete</h1>

@endsection