<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <!-- <title>{{ config('app.name', 'Laravel') }}</title> -->

    <title>E-Auction</title>
    
    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=Nunito" rel="stylesheet">


    <!-- For favicon png -->
    <!-- <link rel="shortcut icon" type="image/icon" href="logo/favicon.png"/> -->
   
    <!--font-awesome.min.css-->
    <link rel="stylesheet" href="css/font-awesome.min.css">

    <!--linear icon css-->
    <link rel="stylesheet" href="css/linearicons.css">

    <!--animate.css-->
    <link rel="stylesheet" href="css/animate.css">

    <!--flaticon.css-->
    <link rel="stylesheet" href="css/flaticon.css">

    <!--slick.css-->
    <link rel="stylesheet" href="css/slick.css">
    <link rel="stylesheet" href="css/slick-theme.css">
    
    <!--bootstrap.min.css-->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    
    <!-- bootsnav -->
    <link rel="stylesheet" href="css/bootsnav.css" > 
    
    <!--style.css-->
    <link rel="stylesheet" href="css/style.css">
    
    <!--responsive.css-->
    <link rel="stylesheet" href="css/responsive.css">

    <!-- Scripts -->
    @vite(['resources/sass/app.scss', 'resources/js/app.js'])
</head>
<body>
    <div id="app">
        
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css" integrity="sha512-5A8nwdMOWrSz20fDsjczgUidUBR8liPYU+WymTZP1lmY9G6Oc7HlZv156XqnsgNUzTyMefFTcsFH/tnJE/+xBg==" crossorigin="anonymous" referrerpolicy="no-referrer" />


        <!--header-top start -->
        <header id="header-top" class="header-top">
            <ul>
                <li>
                    <div class="header-top-left">
                        <ul>
                            <!-- <li class="header-top-contact">
                                +1 222 777 6565
                            </li> -->
                            <li class="select-opt">
                                <select name="language" id="language">
                                    <option value="default">EN</option>
                                    <!-- <option value="Bangla">BN</option>
                                    <option value="Arabic">AB</option> -->
                                </select>
                            </li>
                            <!-- <li class="select-opt">
                                <select name="currency" id="currency">
                                    <option value="usd">USD</option>
                                    <option value="euro">Euro</option>
                                    <option value="bdt">BDT</option>
                                </select>
                            </li>
                            <li class="select-opt">
                                <a href="#"><span class="lnr lnr-magnifier"></span></a>
                            </li> -->
                        </ul>
                    </div>
                </li>
                <li class="head-responsive-right pull-right">
                    <div class="header-top-right">
                        <ul>
                            

                        @guest
                            @if (Route::has('login'))
                                 <li class="header-top-contact">
                                    <a href="{{ route('login') }}">sign in</a>
                                </li>
                            @endif

                            @if (Route::has('register'))
                                <li class="header-top-contact">
                                    <a href="{{ route('register') }}">register</a>
                                </li>
                            @endif
                        @else
                            <li class="header-top-contact">
                                <a href="{{ route('logout') }}"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        {{ __('Logout') }} 
                                    </a>

                                    <form id="logout-form" action="{{ route('logout') }}" method="POST" class="d-none">
                                        @csrf
                                    </form>

                            </li>
                        @endguest


                        
                        </ul>
                    </div>
                </li>
            </ul>
                    
        </header><!--/.header-top-->
        <!--header-top end -->
<link rel="stylesheet" type="text/css" href="assets/css/header.css">
<style>
    /* Chrome, Safari, Edge, Opera */
input::-webkit-outer-spin-button,
input::-webkit-inner-spin-button {
  -webkit-appearance: none;
  margin: 0;
}

/* Firefox */
input[type=number] {
  -moz-appearance: textfield;
}
</style>
<header>
<top>
    <div class="headerTop">
        <div class="row">
            <div class="col-md-2">
              <a class="logo-nav" href="{{ url('/') }}/home">
                <h1>E-Auction</h1>
                <sub>Repairable and Used Cars</sub>
              </a>
            </div>
            <div class="col-md-6">


                    @guest
                            @if (Route::has('login'))
                                 <nav class="navbar bg-body-tertiary">
                                    <div class="container-fluid"> 
                                        <form class="d-flex" role="search" style="display: none;">
                                        <div class="col-md-10">
                                            <input class="form-control" type="search" placeholder="Search" aria-label="Search"/>
                                        </div>
                                        <div class="col-md-2">
                                            <button id="searchBtn" class="btn btn-search" type="submit" style=>Search</button>
                                        </div>
                                        </form>
                                    </div>
                                </nav>  
                            @endif

                        @else
                            <nav class="navbar bg-body-tertiary">
                            <div class="container-fluid"> 
                                <form action="{{ url('/') }}/search-result" method="get" class="d-flex" role="search">
                                <div class="col-md-10">
                                    <input class="form-control" name="lot_number" type="text" placeholder="Search Lot Number" aria-label="Search"/>
                                </div>
                                <div class="col-md-2">
                                    <button id="searchBtn" class="btn btn-search" name="submit" type="submit" style=>Search</button>
                                </div>
                                </form>
                            </div>
                            </nav>  
                        @endguest


                
            </div>
        </div>
    </div>
</top>  
</header>
       <main class="py-4">
           @yield('content')
       </main>

       <!--footer start-->
        <footer id="footer"  class="footer">
            <div class="container">
                <div class="footer-menu">
                    <div class="row">
                        <div class="col-sm-3">
                             <div class="navbar-header">
                            </div><!--/.navbar-header-->
                        </div>
                        <div class="col-sm-9">
                            <ul class="footer-menu-item">
<!--                                 <li class="scroll"><a href="#explore">explore</a></li>
                                <li class="scroll"><a href="#reviews">review</a></li>
                                <li class="scroll"><a href="#blog">blog</a></li> -->
                                <!-- <li class=" scroll"><a href="#contact">my account</a></li> -->
                            </ul><!--/.nav -->
                        </div>
                   </div>
                </div>
                <div class="hm-footer-copyright">
                    <div class="row">
                        <div class="col-sm-12 text-center">
                            <p>
                                &copy; 2025 copyrights, All Rights Reserved.
                            </p><!--/p-->
                        </div>
                        <!-- <div class="col-sm-7">
                            <div class="footer-social">
                                <a href="#"><i class="fa fa-facebook"></i></a>  
                                <a href="#"><i class="fa fa-twitter"></i></a>
                                <a href="#"><i class="fa fa-linkedin"></i></a>
                                <a href="#"><i class="fa fa-google-plus"></i></a>
                            </div>
                        </div> -->
                    </div>
                    
                </div><!--/.hm-footer-copyright-->
            </div><!--/.container-->

            <div id="scroll-Top">
                <!-- <div class="return-to-top">
                    <i class="fa fa-angle-up " id="scroll-top" data-toggle="tooltip" data-placement="top" title="" data-original-title="Back to Top" aria-hidden="true"></i>
                </div> -->
                
            </div><!--/.scroll-Top-->

    </div>
</body>

        <script src="js/jquery.js"></script>
        
        <!--modernizr.min.js-->
        <script src="https://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.3/modernizr.min.js"></script>
        
        <!--bootstrap.min.js-->
        <script src="js/bootstrap.min.js"></script>
        
        <!-- bootsnav js -->
        <script src="js/bootsnav.js"></script>

        <!--feather.min.js-->
        <script  src="js/feather.min.js"></script>

        <!-- counter js -->
        <script src="js/jquery.counterup.min.js"></script>
        <script src="js/waypoints.min.js"></script>

        <!--slick.min.js-->
        <script src="js/slick.min.js"></script>

        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.4.1/jquery.easing.min.js"></script>
             
        <!--Custom JS-->
        <script src="js/custom.js"></script>
</html>
