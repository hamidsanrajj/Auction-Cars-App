@extends('layouts.app')

@section('content')


<link rel="stylesheet" type="text/css" href="assets/css/home.css">




<div class="container" style="margin-bottom: -50px;">
  <div class="row card-car">

@if(isset($rs))
@foreach ($rs as $rse)


    <div class="col-md-3">
      <div class="card">
        <img class="card-img-top" src="uploads/{{ $rse->img1 }}" alt="Card image cap">
        <div class="card-body">
          <h5 class="card-title">{{ $rse->name }}</h5>
          <div><label> Lot#  </label><span> {{ $rse->lot_number }}</span></div>

@if(isset($rs3))
@foreach ($rs3 as $rse)


          <div><label> Current Bid:  </label><span class="price"> $ {{ $rse->bid_amount }} CAD</span></div>

@endforeach
@endif



          <div><label> Location:  </label><span> {{ $rse->location }}</span></div> 
          <div class="row">
            <div class="col-md-3">
              <form action="{{ url('/') }}/detail" method="get">
                @csrf
                <input type="text" name="id" value="{{ $rse->id }}" hidden>
                <button id="detail" name="submit" type="submit" class="btn btn-primary">Detail</button>
              </form>
            </div>
          
            <div class="col-md-3" style="margin-left: 10px;">
              <form action="{{ url('/') }}/bid" method="get">
                @csrf
                <input type="text" name="id" value="{{ $rse->id }}" hidden>
                <button id="detail" name="submit" type="submit" class="btn btn-success">Bid</button>
              </form>
            </div>
          </div>


                <script type="text/javascript">
                var button1 = document.getElementById('detail');
                var button2 = document.getElementById('bid');
                button1.onclick = function() {
                  location.assign('{{ url("/detail") }}');
                }
                button2.onclick = function() {
                  location.assign('{{ url("/bid") }}');
                }
                </script>        

        </div>
      </div>      
    </div>


@endforeach
@endif


  </div>




<!-- <div class="center">
<div class="pagination">
  <a href="#">&laquo;</a>
  <a href="#" class="active">1</a>
  <a href="#">2</a>
  <a href="#">3</a>
  <a href="#">4</a>
  <a href="#">5</a>
  <a href="#">6</a>
  <a href="#">&raquo;</a>
</div>
</div> -->


</div>

@endsection
