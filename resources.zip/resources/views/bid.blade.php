@extends('layouts.app')

@section('content')



<link rel="stylesheet" type="text/css" href="assets/css/bid.css">

<style>
    /* Chrome, Safari, Edge, Opera */
input::-webkit-outer-spin-button,
input::-webkit-inner-spin-button {
  -webkit-appearance: none;
  margin: 0;
}

/* Firefox */
input[type=number] {
  -moz-appearance: textfield;
}
</style>

<car-detail>
    <div class="detail">
        <div class="row">
            <div class="col-md-6 vehicleBid"><div class="vehicleBidHeading"> <h4>Bid Details </h4> </div>


                <!-- <div class="row labelItem" style="">
                    <div class="col-md-6">
                        <div>Total Bids:</div>
                    </div>
                    <div class="col-md-6 vehicleDetailsVal">
                        <div>15</div>
                    </div>
                </div> -->
                <div class="row labelItem" style="">
                    <div class="col-md-6">
                        <div>Time Allocated:</div>
                    </div>
                    <div class="col-md-6 vehicleDetailsVal">
                        <div>1 Week</div>
                    </div>
                </div>
                <div class="row labelItem" style="">
                    <div class="col-md-6">
                        <div>Bid Started:</div>
                    </div>
@if(isset($rs2))
@foreach ($rs2 as $rse)                

                    <div class="col-md-6 vehicleDetailsVal">
                        <div>{{ date('d-m-Y H:i:s', strtotime($rse->created_at)); }}</div>
                    </div>
@endforeach
@endif                    
                </div>
                <div class="row labelItem" style="">
                    <div class="col-md-6">
                        <div>Starting Bid:</div>
                    </div>         

@if(isset($rs3))
@if(count($rs3)>0)
@foreach ($rs3 as $rse)                
                 <div class="col-md-6 vehicleDetailsVal">
                        <div>${{ $rse->bid_amount }} CAD</div>
                    </div>
@endforeach
@else
                  <div class="col-md-6 vehicleDetailsVal">
                        <div>$0 CAD</div>
                  </div>
@endif          
@endif  

                </div>
                <div class="row labelItem" style="">
                    <div class="col-md-6">
                        <div>Current Bid:</div>
                    </div>


@if(isset($rs5))
@if(count($rs5)>0)
@foreach ($rs5 as $rse)                
                 <div class="col-md-6 vehicleDetailsVal">
                        <div><h1 style="color: green; font-size: 30px;">${{ $rse->bid_amount }} CAD</h1></div>
                    </div>
@endforeach
@else
                  <div class="col-md-6 vehicleDetailsVal">
                        <div><h1 style="color: green; font-size: 30px;">$0 CAD</h1></div>
                    </div>
@endif          
@endif  


                </div>



@if(isset($rs2))
@foreach ($rs2 as $rse)



                <form action="{{ url('/') }}/bidding" method="post" onSubmit="location.reload();">
                @csrf
                <input type="text" name="name" value="{{ auth()->user()->name }}" hidden>
                <input type="text" name="email" value="{{ auth()->user()->email }}" hidden>
                <input type="text" name="phone" value="{{ auth()->user()->phone }}" hidden>
                <input type="text" name="city" value="{{ auth()->user()->city }}" hidden>
                <input type="text" name="country" value="{{ auth()->user()->country }}" hidden>
                <input type="text" name="car_id" value="{{ $rse->id }}" hidden>
                <input type="text" name="car_name" value="{{ $rse->name }}" hidden>
                <input type="text" name="lot_number" value="{{ $rse->lot_number }}" hidden>
                <input type="text" name="location" value="{{ $rse->location }}" hidden>

@if(isset($rs5))
@if(count($rs5)>0)
@foreach ($rs5 as $rse)                
                <input min="{{ $rse->bid_amount }}" type="number" name="bid_amount" class="form-control mt-4" required>
@endforeach
@else
                 <input min="0" type="number" name="bid_amount" class="form-control mt-4" required> 
@endif          
@endif          
               
                <button class="form-control btn btn-warning" name="submit" style="margin-top: 10px;">Bid Now</button>
                </form>


@endforeach
@endif

                <hr>

                All bids are legally binding and all sales are final.
                <div class="alerts row mt-2">
                    <h4 style="margin: 15px;">Get Alerts on Similar Car</h4>
                    <div class="col-md-6">
                        <input type="text" class="form-control" placeholder="First Name">
                    </div>
                    <div class="col-md-6">
                        <input type="text" class="form-control" placeholder="Last Name">
                    </div>
                    <div class="col-md-6" style="margin-top: 10px;">
                        <input type="text" class="form-control" placeholder="Email">
                    </div>
                    <div class="col-md-6" style="margin-top: 10px;">
                        <input type="text" class="form-control" placeholder="Zip Code">
                    </div>
                    <div class="col-md-12 py-2">
                        <button class="form-control btn btn-primary mt-2" style="margin-top: 10px; margin-bottom: 10px;">Get Alerts</button>
                    </div>
                </div>

            </div>

@if(isset($rs2))
@foreach ($rs2 as $rse)


            <div class="col-md-6">
                <section>
                    <div>
                        <div class="carousel">
                            <input type="radio" name="slides" checked="checked" id="slide-1">
                            <input type="radio" name="slides" id="slide-2">
                            <input type="radio" name="slides" id="slide-3">
                            <input type="radio" name="slides" id="slide-4">
                            <input type="radio" name="slides" id="slide-5">
                            <input type="radio" name="slides" id="slide-6">
                                <ul class="carousel__slides">
                                    <li class="carousel__slide">
                                        <figure>
                                            <div>
                                                <img src="uploads/{{ $rse->img1 }}" alt="">
                                            </div>
                                            <figcaption>
                                                {{ $rse->name }}
                                                <span class="credit">{{ $rse->lot_number }}</span>
                                            </figcaption>
                                        </figure>
                                    </li>
                                    <li class="carousel__slide">
                                        <figure>
                                            <div>
                                                <img src="uploads/{{ $rse->img2 }}" alt="">
                                            </div>
                                            <figcaption>
                                                {{ $rse->name }}
                                                <span class="credit">{{ $rse->lot_number }}</span>                            
                                            </figcaption>
                                        </figure>
                                    </li>
                                    <li class="carousel__slide">
                                        <figure>
                                            <div>
                                                <img src="uploads/{{ $rse->img3 }}" alt="">
                                            </div>
                                            <figcaption>
                                                {{ $rse->name }}
                                                <span class="credit">{{ $rse->lot_number }}</span>                            
                                            </figcaption>
                                        </figure>
                                    </li>
                                    <li class="carousel__slide">
                                        <figure>
                                            <div>
                                                <img src="uploads/{{ $rse->img4 }}" alt="">
                                            </div>
                                            <figcaption>
                                                {{ $rse->name }}
                                                <span class="credit">{{ $rse->lot_number }}</span>                            
                                            </figcaption>
                                        </figure>
                                    </li>
                                    <li class="carousel__slide">
                                        <figure>
                                            <div>
                                                <img src="uploads/{{ $rse->img5 }}" alt="">
                                            </div>
                                            <figcaption>
                                                {{ $rse->name }}
                                                <span class="credit">{{ $rse->lot_number }}</span>                            
                                            </figcaption>
                                        </figure>
                                    </li>
                                    <li class="carousel__slide">
                                        <figure>
                                            <div>
                                                <img src="uploads/{{ $rse->img6 }}" alt="">
                                            </div>
                                            <figcaption>
                                                {{ $rse->name }}
                                                <span class="credit">{{ $rse->lot_number }}</span>                            
                                            </figcaption>
                                        </figure>
                                    </li>
                                </ul>      
                            <ul class="carousel__thumbnails">
                                <li>
                                    <label for="slide-1"><img src="uploads/{{ $rse->img1 }}" alt=""></label>
                                </li>
                                <li>
                                    <label for="slide-2"><img src="uploads/{{ $rse->img2 }}" alt=""></label>
                                </li>
                                <li>
                                    <label for="slide-3"><img src="uploads/{{ $rse->img3 }}" alt=""></label>
                                </li>
                                <li>
                                    <label for="slide-4"><img src="uploads/{{ $rse->img4 }}" alt=""></label>
                                </li>
                                <li>
                                    <label for="slide-5"><img src="uploads/{{ $rse->img5 }}" alt=""></label>
                                </li>
                                <li>
                                    <label for="slide-6"><img src="uploads/{{ $rse->img6 }}" alt=""></label>
                                </li>
                            </ul>
                        </div>
                    </div>
                </section>

@endforeach
@endif


                <div class="row" style="padding: 20px;">
                        <div class="col-md-6">
@if(isset($id))
                        <form action="{{ url('/') }}/detail" method="get">
                        @csrf
                        <input type="text" name="id" value="{{ $id }}" hidden>                
                        <button id="bid" class="form-control btn btn-primary">View Detail</button>
                        </form>
@endif                        
                        </div>
                        <div class="col-md-6">
                            <button id="other" class="form-control btn btn-success">Other</button>
                        </div>

                        <script type="text/javascript">
                        var button = document.getElementById('bid');
                        button.onclick = function() {
                          location.assign('{{ url("/detail") }}');
                        }

                        var button2 = document.getElementById('other');
                        button2.onclick = function() {
                          location.assign('{{ url("/home") }}');
                        }
                        </script>    
                </div>

            </div>

</div>
</div>
</car-detail>

@endsection