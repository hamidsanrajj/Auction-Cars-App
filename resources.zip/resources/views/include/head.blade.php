<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <title>E-Auction @yield('title') </title>
    <link rel="stylesheet" type="text/css" href="assets/css/style.css">
    <link rel="stylesheet" type="text/css" href="assets/owl/dist/assets/owl-carousel.css">
    <link rel="stylesheet" type="text/css" href="assets/owl/dist/assets/owl-carousel.min.css">
    <link rel="stylesheet" href="assets/docs/assets/css/docs.theme.min.css">
    <link rel="stylesheet" href="assets/owl/docs/assets/owlcarousel/assets/owl.carousel.min.css">
    <link rel="stylesheet" href="assets/owl/docs/assets/owlcarousel/assets/owl.theme.default.min.css">
    <script src="assets/owl/docs/assets/vendors/jquery.min.js"></script>
    <script src="assets/owl/docs/assets/owlcarousel/owl.carousel.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>

<style type="text/css">
  /*Carousel*/
.banner{
  background-image: url('assets/img/banner.jpg'); max-width: 100%; height: 600px;
}
</style>

<header>
<top>
    <div class="header-top">
        <div class="row">
            <div class="col-md-2">
              <a href="{{ route('home') }}" style="text-decoration: none;">
                <h1>E-Auction</h1>
                <sub>Repairable and Used Cars</sub>
              </a>
            </div>
            <div class="col-md-8">
                <nav class="navbar bg-body-tertiary">
                  <div class="container-fluid"> 
                    <form class="d-flex" role="search" action="{{ url('/') }}/login">
                      <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search"/>
                      <button id="searchBtn" class="btn btn-outline-warning me-2" type="submit">Search</button>
                    </form>
                  </div>
                </nav>  
            </div>
            <div class="col-md-2">
                <nav class="navbar bg-body-tertiary">
                  <div class="container-fluid"> 
                    <form class="d-flex" role="search">
                        <a href="{{ route('login') }}" class="btn btn-outline-light me-2" type="submit">Login</a>
                        <a href="{{ route('register') }}" class="btn btn-outline-light" type="submit">Register</a>
                    </form>
                  </div>
                </nav>  
            </div>
        </div>
    </div>
</top>  
<nav id="navbar" class="navbar navbar-expand-lg bg-body-tertiary">
  <div class="container-fluid">
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav">
        <!-- <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="#">Home</a>
        </li> -->
        <li class="nav-item">
          <a class="nav-link" href="#">How it works</a>
        </li>
<!--         <li class="nav-item">
          <a class="nav-link" href="#">Inventory</a>
        </li> -->
                <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Auction
          </a>

          <ul class="dropdown-menu">
            <li><a class="dropdown-item" href="#">Today's Auction</a></li>
            <li><a class="dropdown-item" href="#">Auction Calendar</a></li>
            <li><a class="dropdown-item" href="#">Join Auction</a></li>
          </ul>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Locations</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Services & Support</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Help Center</a>
        </li>
      </ul>
    </div>
  </div>
</nav>  
</header>