<banner>
    <div class="banner">
    </div>
</banner>
